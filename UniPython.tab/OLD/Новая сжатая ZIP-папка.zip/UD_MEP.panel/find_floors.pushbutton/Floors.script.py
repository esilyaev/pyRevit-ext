# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Architecture import *
from Autodesk.Revit.DB.Analysis import *

uidoc = __revit__.ActiveUIDocument
doc = __revit__.ActiveUIDocument.Document

#dependencies


import clr
clr.AddReference('System.Windows.Forms')
clr.AddReference('IronPython.Wpf')

from pyrevit import script
xamlfile = script.get_bundle_file('Viewer.xaml')

import wpf
from System import Windows


def find_floor(config):
  # print config.IdentifyFilterString
  # print config.LevelFilterString
  # print config.IgnoreFilterString
  floors = [i for i in FilteredElementCollector(doc).\
        OfCategory(BuiltInCategory.OST_Floors).WhereElementIsNotElementType()]
  if config.IdentifyFilter:
    floors = [i for i in floors if i.Name.Contains(config.IdentifyFilterString)]
  if config.LevelFilter:
    floors = [i for i in floors if i.Name.Contains(config.LevelFilterString)]
  if config.IgnoreFilter:
    floors = [i for i in floors if not i.Name.Contains(config.IgnoreFilterString)]          

  #print floors
  for elem in floors:
    elemPrim = elem.LookupParameter("ADSK_Примечание")
   # пропускаем те стены у кого "ADSK_Примечание" заполнено
    if elemPrim.AsString() != '' and elemPrim.AsString() != None:
      continue 

    gopt = Options()
    gelem = elem.get_Geometry(gopt)
    solid = GetSolidsOfElement(gelem)[0]
    point = solid.ComputeCentroid()
    offset = 3.28
    room = doc.GetRoomAtPoint(point)  
    if room:
      number = room.get_Parameter(BuiltInParameter.ROOM_NUMBER).AsString()  
      elemPrim.Set(number)
    else:
      room = doc.GetRoomAtPoint(point.Add(XYZ(0,0,offset)))
      if room:
        number = room.get_Parameter(BuiltInParameter.ROOM_NUMBER).AsString()  
        elemPrim.Set(number)
      else:
        elemPrim.Set('Не найдено')


def GetSolidsOfElement(geoElem):
  solids = []
  for  geoObj in geoElem:
    if geoObj.ToString() == 'Autodesk.Revit.DB.GeometryInstance':
      geomIns = geoObj
      instGeoElement = geomIns.GetSymbolGeometry()
      for i in instGeoElement:
        if i.ToString() == 'Autodesk.Revit.DB.Solid':
          if i.Volume == 0:
            pass
          else:
            solids.append(i)
    else:
      if geoObj.ToString() == 'Autodesk.Revit.DB.Solid':
        solids.append(geoObj)
  return solids


class Configurator():
	"""Configurator for Floor scripts"""

	def __init__(self):
		self.IdentifyFilter = False
		self.LevelFilter = False
		self.IgnoreFilter = False
		self.IdentifyFilterString = ""
		self.LevelFilterString = ""
		self.IgnoreFilterString = "ignore"


	def Reset(self):
		self.IdentifyFilter = False
		self.LevelFilter = False
		self.IgnoreFilter = False
		self.IdentifyFilterString = ""
		self.LevelFilterString = ""
		self.IgnoreFilterString = "ignore"
	



class MyWindow(Windows.Window):
	"""UI manager"""
	def __init__(self, xamlfile):
		# load window
		wpf.LoadComponent(self, xamlfile)
		

	def Close_Click(self, sender, args):
		self.Close()

	def Run(self, sender, args):
		t = Transaction(doc, 'find floors')
		t.Start()
		# past run function here -->
		find_floor(config)
		t.Commit()

	def Clear(self, sender, args):
		#clear function from form 
		config.Reset()
		self.IdentifyFilter.IsChecked = False
		self.LevelFilter.IsChecked = False
		self.IgnoreFilter.IsChecked = False

		self.IdentifyFilterString.Text = ""
		self.LevelFilterString.Text = ""
		self.IgnoreFilterString.Text = ""


	# IdentifyFilter toggle in UI elements
	def IdentifyFilter_Unchecked(self, sender, args):
		config.IdentifyFilter = False
	def IdentifyFilter_Checked(self, sender, args):
		config.IdentifyFilter = True

	# LevelFilter toggle in UI elements
	def LevelFilter_Unchecked(self, sender, args):
		config.LevelFilter = False
	def LevelFilter_Checked(self, sender, args):
		config.LevelFilter = True

	# IgnoreFilter toggle in UI elements
	def IgnoreFilter_Unchecked(self, sender, args):
		config.IgnoreFilter = False
	def IgnoreFilter_Checked(self, sender, args):
		config.IgnoreFilter = True

	# TextBox for string IdentifyFilter
	def IdentifyFilterString_Changed(self, sender, args):
		config.IdentifyFilterString = self.IdentifyFilterString.Text

	# TextBox for string LevelFilter
	def LevelFilterString_Changed(self, sender, args):
		config.LevelFilterString = self.LevelFilterString.Text

	# TextBox for string IgnoreFilter
	def IgnoreFilterString_Changed(self, sender, args):
		config.IgnoreFilterString = self.IgnoreFilterString.Text


config = Configurator()
MyWindow(xamlfile).ShowDialog()
